import dotenv from 'dotenv';
import path from 'path';
import { FakerData } from '../../helpers/fakerUtils';
dotenv.config({ path: path.join(__dirname, "oauthData.env")});

export const oauthData = {
    // For salesforce Summer'26 release [Latest] 
    grant_type: 'client_credentials',
    client_id: process.env.CLIENT_ID!,
    client_secret: process.env.CLIENT_SECRET!,
    // For salesforce Spring'26 release [other version below it] 
   // username: process.env.SFUSERNAME!,
  //  password: process.env.SFPASSWORD!,
}
export const createLeaddata = {
    "FirstName": FakerData.getFirstName(),
    "LastName": FakerData.getLastName(),
    "Company": "Qeagle"
};

export const updateLeadData = {

    "FirstName": FakerData.getFirstName(),
    "Title": "SDET",
    "Street": FakerData.getStreet(),
    "City": FakerData.getCity(),
    "State": FakerData.getState(),
    "PostalCode": FakerData.getPinCode(),
    "Country": FakerData.getCountry(),
    "MobilePhone": FakerData.getMobileNumber(),
    "Email": FakerData.getEmail(),
    "Website": FakerData.getWebsite(),
}