

/* const managerName: any = data.managerName
const commonUser: any = data.commonUser
const internalUser: any = data.internalUser
const externalUser: any = data.externalUser
const teamUser1: any = data.teamUser1
const teamUser2: any = data.teamUser2 */

export let credentials = {

    ADMINLOGIN: {
        username: "seenivasan.shanmugam.c2f550ec7762@agentforce.com",
        password: "Test@2026"
    },
    USERLOGIN: {
        username: "bhuvanesh.qeagle.1ce512d00545@agentforce.com",
        password: "Qeagle@2026"
    }
};