export enum URLConstants {
    adminURL = "https://orgfarm-8ea80f3b91-dev-ed.develop.lightning.force.com/lightning/page/home"
    //adminURL = "https://orgfarm-8ea80f3b91-dev-ed.develop.lightning.force.com"
}