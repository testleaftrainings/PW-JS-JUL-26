import axios, { AxiosRequestConfig, AxiosResponse } from "axios";

export async function httpRequest(
    method: "get" | "post" | "put" | "delete" | "patch",
    endPoint: string,
    userData?: any,
    customHeaders?: Record<string, string>,
    additionalConfig?: AxiosRequestConfig
): Promise<any> {

    let requestBody = userData;

    const headers = {
        "Connection": "keep-alive",
        ...customHeaders
    };

    const contentType = headers["Content-Type"]?.toLowerCase();

    // Handle x-www-form-urlencoded
    if (contentType === "application/x-www-form-urlencoded") {

        requestBody = new URLSearchParams();

        Object.entries(userData).forEach(([key, value]) => {
            requestBody.append(key, String(value));
        });

    }

    // Handle multipart/form-data
    else if (contentType === "multipart/form-data") {

        requestBody = new FormData();

        Object.entries(userData).forEach(([key, value]) => {
            requestBody.append(key, value as any);
        });

        // Let Axios generate the boundary automatically
        delete headers["Content-Type"];
    }

    // Handle JSON
    else {

        headers["Content-Type"] = "application/json";
        requestBody = userData;
    }

    try {

        const response: AxiosResponse = await axios({

            method,
            url: endPoint,
            headers,
            data: method !== "get" ? requestBody : undefined,
            ...additionalConfig

        });

        return {
            data: response.data,
            status: `${response.status} ${response.statusText}`
        };

    } catch (error) {
        console.error(`Error making ${method.toUpperCase()} request`, error);
        throw error;
    }
}