/**
 * This file contains Cucumber hooks for test initialization and cleanup
 * It handles browser setup, screenshot capture, and test environment management
 */

import { Before, After, AfterStep, BeforeAll, AfterAll, Status, setDefaultTimeout } from '@cucumber/cucumber';
import { chromium, firefox, webkit } from '@playwright/test';
import fs from 'fs-extra';
import { BROWSER, STEP_TIMEOUT, browserOptions, screenshotOptions, videoOptions, traceOptions } from '../config/config';
import { createLogger } from '../utils/logger';
import { CustomWorld } from './custom-world';
import { PlaywrightWrapper } from '../utils/wrapper';
import { AccountPage } from '../pages/account.page';
import { LeadsPage } from '../pages/leads.page';
import { LoginPage } from '../pages/login.page';

// Initialize logger for this module
const logger = createLogger('hooks');
// Set global timeout for all steps based on config value
setDefaultTimeout(STEP_TIMEOUT);

/**
 * BeforeAll hook - Runs once before any tests execute
 * Creates necessary directories for test artifacts
 */
BeforeAll(async function () {
  logger.info('Setting up test environment');
  // Ensure directories exist for storing test artifacts
  await fs.ensureDir('./reports/screenshots');  // Directory for screenshot storage
  await fs.ensureDir('./reports/videos');       // Directory for video recordings
  await fs.ensureDir('./reports/traces');       // Directory for Playwright traces
  await fs.emptyDir('./reports/allure-results'); // Keep each Allure report limited to the current run
  await fs.ensureDir('./logs');                  // Directory for log files
  logger.info('Test environment setup complete');
});

/**
 * AfterAll hook - Runs once after all tests have completed
 * Performs any final cleanup operations
 */
AfterAll(async function () {
  logger.info('Cleaning up test environment');
  // Placeholder for any cleanup operations needed after all tests
  logger.info('Test environment cleanup complete');
});

/**
 * Before hook - Runs before each scenario
 * Sets up browser instance and context based on configuration
 * 
 * @param {CustomWorld} this - The custom world instance for this scenario
 * @param {Object} scenario - The current scenario information
 * @param {Object} scenario.pickle - Contains scenario details
 * @param {string} scenario.pickle.name - Name of the current scenario
 */
Before(async function (this: CustomWorld, scenario) {
  // Record start time for duration calculation
  this.startTime = new Date();
  // Format test name for file naming (replace spaces with dashes)
  this.testName = scenario.pickle.name.replace(/\s+/g, '-');
  logger.info(`Starting scenario: ${this.testName}`);

  const browserType = this.parameters.browser || BROWSER;
  logger.info(`Using browser: ${browserType}`);
  
  // Launch appropriate browser based on browser type parameter
  switch (browserType.toLowerCase()) {
    case 'chrome':
      // Launch Chrome browser with options from config
      this.browser = await chromium.launch(browserOptions.chrome);
      break;
    case 'msedge':
      // Launch Edge browser with options from config (uses chromium engine)
      this.browser = await chromium.launch(browserOptions.msedge);
      break;
    case 'firefox':
      // Launch Firefox browser with options from config
      this.browser = await firefox.launch(browserOptions.firefox);
      break;
    case 'webkit':
      // Launch Safari/WebKit browser with options from config
      this.browser = await webkit.launch(browserOptions.webkit);
      break;
    default:
      // Throw error if unsupported browser specified
      throw new Error(`Unsupported browser type: ${browserType}`);
  }

  const shouldSetViewportNull = ["chrome", "msedge", "chromium", "firefox"].includes(browserType.toLowerCase());

  // Configure browser context options
  const contextOptions = {
    // Configure video recording based on config settings
    recordVideo: videoOptions.enabled ? { dir: videoOptions.path } : undefined,
    // Set viewport to null for specific browsers to enable maximized window
    ...(shouldSetViewportNull ? { viewport: null } : {})
  };

  // Create new browser context with the specified options
  this.context = await this.browser.newContext(contextOptions);

  // Start tracing if enabled in configuration
  if (traceOptions.enabled) {
    await this.context.tracing.start({
      screenshots: true,  // Include screenshots in trace
      snapshots: true,    // Include DOM snapshots in trace
    });
  }

  // Create a new page in the browser context
  this.page = await this.context.newPage();
  this.wrapper = new PlaywrightWrapper(this.page, this.context);
  this.loginPage = new LoginPage(this.wrapper);
  this.accountPage = new AccountPage(this.wrapper);
  this.leadsPage = new LeadsPage(this.wrapper);
});

AfterStep(async function (this: CustomWorld, { pickleStep, result }): Promise<void> {
  if (!this.page) {
    return;
  }

  const stepPassed = result?.status === Status.PASSED;
  const stepFailed = result?.status === Status.FAILED;
  const shouldCaptureScreenshot = stepFailed
    ? screenshotOptions.takeOnFailure
    : stepPassed && screenshotOptions.takeOnSuccess;

  if (!shouldCaptureScreenshot) {
    return;
  }

  const stepName = pickleStep.text
    .replace(/[^a-z0-9]+/gi, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 80);
  const suffix = stepFailed ? 'failure' : 'success';
  const screenshotPath = `${screenshotOptions.path}${this.testName}-${stepName}-${Date.now()}-${suffix}.png`;
  const screenshot = await this.page.screenshot({ path: screenshotPath, fullPage: false });

  this.attach(screenshot, 'image/png');
  logger.info(`Step screenshot saved to: ${screenshotPath}`);
});

/**
 * After hook - Runs after each scenario
 * Captures screenshots on failure, saves traces, and closes browser
 * 
 * @param {CustomWorld} this - The custom world instance for this scenario
 * @param {Object} scenario - The completed scenario information
 * @param {Object} scenario.result - Contains result details
 * @param {Status} scenario.result.status - Status of the scenario (PASSED, FAILED, etc.)
 */
After(async function (this: CustomWorld, scenario) {
  logger.info(`Finishing scenario: ${this.testName}`);

  const scenarioFailed = scenario.result?.status === Status.FAILED;
  const shouldCaptureScreenshot = scenarioFailed
    ? screenshotOptions.takeOnFailure
    : scenario.result?.status === Status.PASSED && screenshotOptions.takeOnSuccess;

  if (this.page && shouldCaptureScreenshot) {
      // Generate timestamp for unique filename
      const timeStamp = Date.now();
      // Create screenshot path with scenario name and timestamp
      const suffix = scenarioFailed ? 'failure' : 'success';
      const screenshotPath = `${screenshotOptions.path}${this.testName}-${timeStamp}-${suffix}.png`;
      
      // Take screenshot and save to file
      await this.page.screenshot({ path: screenshotPath, fullPage: false });
      
      // Read screenshot file and attach to test report
      const screenshot = fs.readFileSync(screenshotPath);
      this.attach(screenshot, 'image/png');

      logger.info(`Screenshot saved to: ${screenshotPath}`);
  }

  // Save trace file if tracing is enabled
  if (traceOptions.enabled && this.context) {
    // Generate timestamp for unique filename
    const timeStamp = Date.now();
    // Create trace path with scenario name and timestamp
    const tracePath = `${traceOptions.path}${this.testName}${timeStamp}.zip`;
    
    // Stop tracing and save trace file
    await this.context.tracing.stop({ path: tracePath });
    
    // Read trace file and attach to test report for Allure integration
    const trace = fs.readFileSync(tracePath);
    this.attach(trace, 'application/zip');
    
    logger.info(`Trace saved to: ${tracePath}`);
  }

  // Close browser instance
  if (this.browser) {
    await this.browser.close();
  }

  // Calculate and log test duration
  const endTime = new Date();
  const duration = endTime.getTime() - this.startTime.getTime();
  logger.info(`Scenario completed in ${duration}ms`);
});